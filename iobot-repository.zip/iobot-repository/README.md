# IoBot 2.0 — community recreation

A React + Vite recreation of the public-facing IoBot 2.0 school-day organizer page at `https://iobot04.web.app/#bulletin`.

> This is a clean recreation based on publicly visible page content, not recovered original source code. Review all copy and interactions against your intended product before publishing.

## Requirements

- Node.js 18.18+ (Node.js 20 LTS recommended)
- npm

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually `http://localhost:5173`).

## Production build

```bash
npm run build
npm run preview
```

The production site is generated in `dist/`.

## Deploy to Firebase Hosting

If you already have a Firebase project, install the Firebase CLI and sign in:

```bash
npm install -g firebase-tools
firebase login
firebase init hosting
```

When prompted, choose the existing Firebase project, set the public directory to `dist`, configure it as a single-page app (`Yes`), and do not overwrite the generated `index.html`. Then build and deploy:

```bash
npm run build
firebase deploy
```

For a Vite single-page app, make sure Firebase Hosting rewrites unknown routes to `/index.html`. A typical `firebase.json` is:

```json
{
  "hosting": {
    "public": "dist",
    "ignore": ["firebase.json", "**/.*", "**/node_modules/**"],
    "rewrites": [{ "source": "**", "destination": "/index.html" }]
  }
}
```

## Project layout

```text
iobot-repository/
├── index.html
├── package.json
├── vite.config.js
├── README.md
└── src/
    ├── App.jsx
    ├── main.jsx
    └── styles.css
```

## Current features

- Responsive landing page and dashboard layout
- Overview, Bulletin, and My day navigation
- Grade selector stored in browser `localStorage`
- Device-local checklist interactions
- Personalization modal
- `#bulletin` hash support

## Important notes

- This version uses sample schedule and bulletin content. Replace it with your actual school data before launch.
- The grade selection and checklist are saved or maintained locally in the browser; there is no backend or account system.
- Do not put secrets, API keys, or private school/student information in client-side source files.
- The page uses Google Fonts via CSS; remove the import if you want a fully self-hosted app.
