import { useEffect, useState } from "react";
import { ArrowUpRight, Bell, BookOpen, CalendarDays, Check, ChevronDown, CircleHelp, Clock3, Menu, Sparkles, X } from "lucide-react";

const days = [
  { time: "8:15 AM", subject: "Homeroom", room: "Room 204", color: "lavender" },
  { time: "9:00 AM", subject: "English", room: "Room 118", color: "peach" },
  { time: "10:05 AM", subject: "Biology", room: "Science lab", color: "mint" },
  { time: "11:10 AM", subject: "World History", room: "Room 212", color: "blue" },
];

const bulletins = [
  { tag: "REMINDER", title: "Keep an eye on upcoming deadlines", body: "Add your assignments and important dates so everything stays in one place.", date: "For your week" },
  { tag: "SCHOOL LIFE", title: "A fresh start, every school day", body: "Use your personal space to keep track of the little things between classes.", date: "Welcome to IoBot" },
];

export default function App() {
  const [grade, setGrade] = useState(() => localStorage.getItem("iobot-grade") || "");
  const [activeTab, setActiveTab] = useState("Overview");
  const [showPersonalize, setShowPersonalize] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [checked, setChecked] = useState([false, false, false]);

  useEffect(() => {
    if (window.location.hash === "#bulletin") setActiveTab("Bulletin");
  }, []);

  function changeTab(tab) {
    setActiveTab(tab);
    setMenuOpen(false);
    if (tab === "Bulletin") window.history.replaceState(null, "", "#bulletin");
    else window.history.replaceState(null, "", "#");
  }

  function saveGrade(value) {
    setGrade(value);
    if (value) localStorage.setItem("iobot-grade", value);
    else localStorage.removeItem("iobot-grade");
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#" onClick={() => changeTab("Overview")} aria-label="IoBot home">
          <span className="brand-mark"><Sparkles size={18} strokeWidth={2.3} /></span>
          <span>IoBot <span className="brand-version">2.0</span></span>
        </a>
        <nav className={`desktop-nav ${menuOpen ? "nav-open" : ""}`} aria-label="Main navigation">
          {["Overview", "Bulletin", "My day"].map((tab) => (
            <button key={tab} className={`nav-link ${activeTab === tab ? "active" : ""}`} onClick={() => changeTab(tab)}>{tab}</button>
          ))}
        </nav>
        <div className="topbar-actions">
          <button className="icon-button" aria-label="Help" title="Help"><CircleHelp size={19} /></button>
          <button className="profile-button" onClick={() => setShowPersonalize(true)}><span className="profile-dot">✦</span><span>My space</span></button>
          <button className="mobile-menu icon-button" aria-label="Toggle navigation" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X size={20} /> : <Menu size={20} />}</button>
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-star">✦</span> YOUR SCHOOL, CONNECTED</div>
            <h1>A little more<br /><span>organized.</span><br />A lot more ready.</h1>
            <p className="hero-subtitle">A calmer way to keep up with your school day — all in one little space made for you.</p>
            <button className="primary-button" onClick={() => setShowPersonalize(true)}>Personalize your space <ArrowUpRight size={17} /></button>
            <div className="hero-note"><span className="tiny-check"><Check size={12} /></span> Your space, your pace. Start wherever you are.</div>
          </div>
          <div className="hero-art" aria-label="Illustration of a student planner">
            <div className="art-sun"></div>
            <div className="art-spark spark-one">✳</div><div className="art-spark spark-two">✦</div>
            <div className="art-card card-back"><div className="mock-line short"></div><div className="mock-line"></div><div className="mock-line medium"></div><div className="mock-pill"></div></div>
            <div className="art-card planner-card">
              <div className="planner-top"><span>YOUR DAY</span><span className="planner-icon"><CalendarDays size={15}/></span></div>
              <div className="planner-date">A good day to begin.</div>
              <div className="planner-task"><span className="task-dot lilac"></span><div><b>First things first</b><small>Take a breath</small></div><Check size={15} className="task-check"/></div>
              <div className="planner-task"><span className="task-dot orange"></span><div><b>One thing at a time</b><small>You’ve got this</small></div><span className="task-ring"></span></div>
              <div className="planner-task"><span className="task-dot green"></span><div><b>Make room to reset</b><small>Little breaks count</small></div><span className="task-ring"></span></div>
              <div className="planner-footer"><span></span><span></span><span></span><span></span></div>
            </div>
            <div className="floating-note"><span className="floating-icon"><Sparkles size={16}/></span><span><b>You're right on track</b><small>Small steps add up.</small></span></div>
          </div>
          <div className="hero-orb orb-left"></div>
        </section>

        <section className="workspace" id="workspace">
          <div className="section-heading">
            <div><div className="eyebrow muted">YOUR SCHOOL DAY, SIMPLIFIED</div><h2>Your day <span>/</span> {activeTab}</h2></div>
            <div className="device-label"><span className="device-dot"></span> On this device</div>
          </div>

          <div className="dashboard-grid">
            <aside className="side-panel panel">
              <div className="panel-label">YOUR SPACE</div>
              <button className={`side-link ${activeTab === "Overview" ? "selected" : ""}`} onClick={() => changeTab("Overview")}><CalendarDays size={17}/> Overview <span className="side-chevron">›</span></button>
              <button className={`side-link ${activeTab === "Bulletin" ? "selected" : ""}`} onClick={() => changeTab("Bulletin")}><Bell size={17}/> Bulletin <span className="side-count">2</span></button>
              <button className={`side-link ${activeTab === "My day" ? "selected" : ""}`} onClick={() => changeTab("My day")}><BookOpen size={17}/> My day</button>
              <div className="side-divider"></div>
              <div className="grade-label">YOUR GRADE</div>
              <label className="select-wrap"><select value={grade} onChange={(e) => saveGrade(e.target.value)} aria-label="Select grade"><option value="">Select grade</option>{["6th grade","7th grade","8th grade","9th grade","10th grade","11th grade","12th grade"].map(g => <option key={g}>{g}</option>)}</select><ChevronDown size={16}/></label>
              <p className="local-note"><span className="lock-dot"></span> Saved on this device</p>
            </aside>

            <section className="main-panel panel">
              {activeTab === "Bulletin" ? (
                <div className="bulletin-view">
                  <div className="content-title-row"><div><div className="panel-label">THE LATEST</div><h3>School bulletin</h3></div><span className="round-icon"><Bell size={18}/></span></div>
                  <p className="content-intro">A little place for notes, reminders, and things worth keeping in mind.</p>
                  <div className="bulletin-list">{bulletins.map((item) => <article className="bulletin-item" key={item.title}><div className="bulletin-tag">{item.tag}</div><h4>{item.title}</h4><p>{item.body}</p><div className="bulletin-date">{item.date}</div></article>)}</div>
                </div>
              ) : activeTab === "My day" ? (
                <div className="day-view">
                  <div className="content-title-row"><div><div className="panel-label">YOUR PLAN</div><h3>Make today yours</h3></div><span className="round-icon"><Clock3 size={18}/></span></div>
                  <p className="content-intro">A few small intentions can make a busy day feel easier.</p>
                  <div className="checklist">{["Check your schedule","Pack what you need","Take a little break"].map((item, i) => <button key={item} className={`check-row ${checked[i] ? "is-checked" : ""}`} onClick={() => setChecked(old => old.map((v,j) => i === j ? !v : v))}><span className="checkbox">{checked[i] && <Check size={14}/>}</span><span>{item}</span></button>)}</div>
                  <div className="progress-copy">{checked.filter(Boolean).length} of 3 little things done</div>
                  <div className="progress-track"><span style={{width: `${checked.filter(Boolean).length / 3 * 100}%`}}></span></div>
                </div>
              ) : (
                <div className="overview-view">
                  <div className="content-title-row"><div><div className="panel-label">A FRESH START</div><h3>Welcome to your day.</h3></div><span className="round-icon"><Sparkles size={18}/></span></div>
                  <p className="content-intro">{grade ? `A little space for your ${grade} year. ` : "Your school day can get busy. Let's make it feel a little more manageable. "}Start with what matters today.</p>
                  <div className="schedule-heading"><span>YOUR ROUTINE</span><button onClick={() => changeTab("My day")}>View my day <ArrowUpRight size={14}/></button></div>
                  <div className="schedule-list">{days.map((item) => <div className="schedule-row" key={item.subject}><span className={`schedule-color ${item.color}`}></span><span className="schedule-time">{item.time}</span><div className="schedule-info"><b>{item.subject}</b><small>{item.room}</small></div><span className="schedule-arrow">↗</span></div>)}</div>
                  <div className="gentle-reminder"><span className="reminder-star">✦</span><span><b>A gentle reminder</b><small>You don't have to do everything at once.</small></span></div>
                </div>
              )}
            </section>

            <aside className="right-panel">
              <div className="quote-card"><div className="quote-mark">“</div><p>You don't need to have it all figured out to take the next step.</p><div className="quote-bottom"><span></span><span> A NOTE TO YOU</span></div><div className="quote-decoration">✳</div></div>
              <div className="help-card"><span className="help-icon"><Sparkles size={16}/></span><div><b>Make it yours</b><p>Choose your grade and explore your personal space.</p><button onClick={() => setShowPersonalize(true)}>Get started <ArrowUpRight size={13}/></button></div></div>
            </aside>
          </div>
        </section>
      </main>

      <footer className="footer"><a className="footer-brand" href="#"><span className="brand-mark small"><Sparkles size={13}/></span> IoBot 2.0</a><span>Made for the moments between classes.</span><span className="footer-status"><span></span> Device-local data · Not an official school service</span></footer>

      {showPersonalize && <div className="modal-backdrop" role="presentation" onMouseDown={(e) => { if (e.target === e.currentTarget) setShowPersonalize(false); }}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><button className="modal-close icon-button" onClick={() => setShowPersonalize(false)} aria-label="Close"><X size={19}/></button><div className="modal-spark"><Sparkles size={22}/></div><div className="eyebrow muted">A SPACE THAT'S YOURS</div><h3 id="modal-title">Let's personalize your space.</h3><p>Choose your grade to make your IoBot experience feel a little more like you.</p><label className="modal-label" htmlFor="modal-grade">What grade are you in?</label><label className="select-wrap modal-select"><select id="modal-grade" value={grade} onChange={(e) => saveGrade(e.target.value)}><option value="">Select grade</option>{["6th grade","7th grade","8th grade","9th grade","10th grade","11th grade","12th grade"].map(g => <option key={g}>{g}</option>)}</select><ChevronDown size={16}/></label><button className="primary-button modal-submit" onClick={() => { setShowPersonalize(false); changeTab("Overview"); }}>Save my space <ArrowUpRight size={16}/></button><p className="modal-footnote"><span className="lock-dot"></span> Your selection stays in this browser.</p></section></div>}
    </div>
  );
}